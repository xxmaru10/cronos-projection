# @xxmaru10/cronos-projection

Lógica de projeção de estado compartilhada entre frontend e backend do CronosVTT.

Contém: `computeState`, reducers de sistema (Fate, Vampire, Fate Acelerado), tipos de domínio, utilitários de identidade.

**Sem dependências de UI** — pode rodar no Node.js (backend) e no browser (frontend).

---

## Setup inicial (fazer uma vez)

### 1. Clonar e fazer o primeiro push

```bash
# Clonar este repo (já criado em github.com/xxmaru10/cronos-projection)
git clone https://github.com/xxmaru10/cronos-projection.git
cd cronos-projection

# Copiar os arquivos gerados para cá
# (ou já estão aqui se você recebeu o zip)

git add .
git commit -m "feat: initial release"
git push origin main

# O GitHub Actions publica automaticamente no GitHub Packages
```

### 2. Instalar no backend (back_sistema_rpg)

```bash
# 1. Criar .npmrc na raiz do repo (já está em backend.npmrc neste pacote)
echo "//npm.pkg.github.com/:_authToken=\${NPM_TOKEN}" > .npmrc
echo "@xxmaru10:registry=https://npm.pkg.github.com" >> .npmrc

# 2. Adicionar ao .gitignore (não commitar o .npmrc com token)
echo ".npmrc" >> .gitignore

# 3. Instalar o pacote
NPM_TOKEN=seu_pat_aqui npm install @xxmaru10/cronos-projection

# 4. Adicionar NPM_TOKEN como secret no GitHub Actions
# github.com/xxmaru10/back_sistema_rpg → Settings → Secrets → NPM_TOKEN
```

### 3. Instalar no frontend (front_sistema_rpg)

```bash
# Mesmo processo do backend
echo "//npm.pkg.github.com/:_authToken=\${NPM_TOKEN}" > .npmrc
echo "@xxmaru10:registry=https://npm.pkg.github.com" >> .npmrc
echo ".npmrc" >> .gitignore

NPM_TOKEN=seu_pat_aqui npm install @xxmaru10/cronos-projection

# NPM_TOKEN como secret no GitHub Actions do frontend também
```

### 4. Atualizar o CI do backend

Substituir `.github/workflows/ci.yml` pelo conteúdo de `backend-ci.yml` deste pacote.

Atualizar o `Dockerfile` conforme `Dockerfile.backend.example`.

---

## Uso

### No backend (SnapshotWorker)

```typescript
import { computeStateFromEvents, applySceneDialogueRetention } from '@xxmaru10/cronos-projection';

// Projeta estado a partir de eventos
const state = computeStateFromEvents(deltaEvents, baseState);

// Poda diálogos antes de salvar snapshot
const pruned = applySceneDialogueRetention(state);
```

### No frontend (opcional — pode continuar usando @/lib/projections diretamente)

```typescript
import { computeState, initialState } from '@xxmaru10/cronos-projection';

const state = computeState(events, initialState);
```

---

## Publicar uma nova versão

O workflow publica automaticamente a cada push na `main` com bump de patch.

Para bump manual de minor ou major:

```bash
npm version minor  # ou major
git push origin main
```

---

## Manter em sync com o frontend

Quando `front_sistema_rpg/src/lib/projections.ts` mudar, atualizar:
- `src/projections.ts` (lógica base)

Quando um reducer de sistema mudar:
- `src/systems/vampire/index.ts` ← de `vampire/reducer.ts`
- `src/systems/fate-accelerated/index.ts` ← de `fate-accelerated/reducer.ts`
- `src/systems/fate/types.ts` ← DEFAULT_SKILLS de `fate/types.ts`

Quando `src/lib/identity.ts` mudar:
- `src/identity.ts`

**Dica:** adicionar um comentário `// MANTER EM SYNC com cronos-projection` nos arquivos fonte do frontend ajuda a lembrar.
