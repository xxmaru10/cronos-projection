// src/systems/fate/types.ts
// Copiado de front_sistema_rpg/src/systems/fate/types.ts — manter em sync.

export const DEFAULT_SKILLS = [
  "Atirar", "Atletismo", "Comunicação", "Condução",
  "Conhecimentos", "Contatos", "Empatia", "Enganar",
  "Furtividade", "Investigar", "Lutar", "Ofícios",
  "Percepção", "Provocar", "Recursos", "Roubo",
  "Ocultismo", "Vigor", "Vontade",
] as const;

export type FateSkill = (typeof DEFAULT_SKILLS)[number];

export type StressTrackValues = {
  physical: number[];
  mental: number[];
  unified?: number[];
};
